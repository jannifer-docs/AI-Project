[CmdletBinding()]
param(
    [Parameter(Mandatory = $false)]
    [string]$InputPath = '',

    [bool]$Recurse = $false,

    [ValidateSet('Skip', 'Overwrite', 'Rename')]
    [string]$ConflictAction = 'Skip',

    [string[]]$Extensions = @('.docx', '.doc'),

    [ValidateSet('None', 'Headings', 'WordBookmarks')]
    [string]$BookmarkMode = 'Headings',

    [string]$LogFile,

    [ValidateRange(0, 3)]
    [int]$RetryCount = 1
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# If InputPath is omitted, convert files in the script's sibling directory.
if ([string]::IsNullOrWhiteSpace($InputPath)) {
    $InputPath = Split-Path -Path $PSCommandPath -Parent
    Write-Host ("No InputPath specified. Using script directory: {0}" -f $InputPath)
}

function Write-Log {
    param(
        [string]$Message,
        [ValidateSet('INFO', 'WARN', 'ERROR')]
        [string]$Level = 'INFO'
    )

    $line = "[{0}] [{1}] {2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Level, $Message
    Write-Host $line

    if ($LogFile) {
        Add-Content -LiteralPath $LogFile -Value $line -Encoding UTF8
    }
}

function Resolve-OutputPath {
    param(
        [string]$DesiredPath,
        [string]$Action
    )

    if (-not (Test-Path -LiteralPath $DesiredPath)) {
        return $DesiredPath
    }

    switch ($Action) {
        'Skip' { return $null }
        'Overwrite' { return $DesiredPath }
        'Rename' {
            $dir = Split-Path -Path $DesiredPath -Parent
            $base = [System.IO.Path]::GetFileNameWithoutExtension($DesiredPath)
            $ext = [System.IO.Path]::GetExtension($DesiredPath)
            $index = 1
            while ($true) {
                $candidate = Join-Path -Path $dir -ChildPath ("{0} ({1}){2}" -f $base, $index, $ext)
                if (-not (Test-Path -LiteralPath $candidate)) {
                    return $candidate
                }
                $index++
            }
        }
    }
}

function Get-TargetFiles {
    param(
        [string]$Path,
        [bool]$SearchRecursively,
        [string[]]$AllowedExtensions
    )

    $normalizedExt = $AllowedExtensions | ForEach-Object {
        if ($_.StartsWith('.')) { $_.ToLowerInvariant() } else { ".{0}" -f $_.ToLowerInvariant() }
    }

    if (-not (Test-Path -LiteralPath $Path)) {
        throw "InputPath does not exist: $Path"
    }

    $item = Get-Item -LiteralPath $Path

    if ($item.PSIsContainer) {
        $files = Get-ChildItem -LiteralPath $Path -File -Recurse:$SearchRecursively
    }
    else {
        $files = @($item)
    }

    return $files | Where-Object { $normalizedExt -contains $_.Extension.ToLowerInvariant() }
}

function Convert-WordToPdf {
    param(
        [object]$WordApp,
        [System.IO.FileInfo]$SourceFile,
        [string]$TargetPdfPath,
        [int]$Retries,
        [int]$CreateBookmarksMode
    )

    $attempt = 0
    while ($attempt -le $Retries) {
        $doc = $null
        try {
            $attempt++
            $doc = $WordApp.Documents.Open($SourceFile.FullName, $false, $true)
            $doc.ExportAsFixedFormat(
                $TargetPdfPath,
                17,
                $false,
                0,
                0,
                0,
                0,
                0,
                $true,
                $true,
                $CreateBookmarksMode
            )
            return $true
        }
        catch {
            if ($attempt -gt $Retries) {
                throw
            }
            Write-Log -Level 'WARN' -Message ("Retrying ({0}/{1}) for: {2}. Error: {3}" -f $attempt, $Retries, $SourceFile.FullName, $_.Exception.Message)
        }
        finally {
            if ($null -ne $doc) {
                $doc.Close([ref]$false)
                [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($doc)
            }
        }
    }

    return $false
}

$stats = [ordered]@{
    Total = 0
    Success = 0
    Failed = 0
    Skipped = 0
}

$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
$word = $null

$bookmarkModeMap = @{
    None = 0
    Headings = 1
    WordBookmarks = 2
}
$bookmarkModeValue = $bookmarkModeMap[$BookmarkMode]

try {
    $files = Get-TargetFiles -Path $InputPath -SearchRecursively $Recurse -AllowedExtensions $Extensions
    $stats.Total = @($files).Count

    if ($stats.Total -eq 0) {
        Write-Log -Level 'WARN' -Message 'No Word files found to convert.'
        return
    }

    Write-Log -Message ("Found {0} file(s). Starting conversion... InputPath={1}; Recurse={2}; BookmarkMode={3}; ConflictAction={4}" -f $stats.Total, $InputPath, $Recurse, $BookmarkMode, $ConflictAction)

    $word = New-Object -ComObject Word.Application
    $word.Visible = $false
    $word.DisplayAlerts = 0

    $index = 0
    foreach ($file in $files) {
        $index++
        $targetPath = [System.IO.Path]::ChangeExtension($file.FullName, '.pdf')
        $resolvedTarget = Resolve-OutputPath -DesiredPath $targetPath -Action $ConflictAction

        if (-not $resolvedTarget) {
            $stats.Skipped++
            Write-Log -Level 'INFO' -Message ("[{0}/{1}] Skipped existing: {2}" -f $index, $stats.Total, $targetPath)
            continue
        }

        try {
            if ($ConflictAction -eq 'Overwrite' -and (Test-Path -LiteralPath $resolvedTarget)) {
                Remove-Item -LiteralPath $resolvedTarget -Force
            }

            [void](Convert-WordToPdf -WordApp $word -SourceFile $file -TargetPdfPath $resolvedTarget -Retries $RetryCount -CreateBookmarksMode $bookmarkModeValue)
            $stats.Success++
            Write-Log -Message ("[{0}/{1}] Converted: {2} -> {3}" -f $index, $stats.Total, $file.Name, (Split-Path -Path $resolvedTarget -Leaf))
        }
        catch {
            $stats.Failed++
            Write-Log -Level 'ERROR' -Message ("[{0}/{1}] Failed: {2}. Error: {3}" -f $index, $stats.Total, $file.FullName, $_.Exception.Message)
        }
    }
}
finally {
    if ($null -ne $word) {
        $word.Quit()
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($word)
    }

    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    $stopwatch.Stop()
    Write-Host ''
    Write-Host '========== SUMMARY =========='
    Write-Host ("Total   : {0}" -f $stats.Total)
    Write-Host ("Success : {0}" -f $stats.Success)
    Write-Host ("Skipped : {0}" -f $stats.Skipped)
    Write-Host ("Failed  : {0}" -f $stats.Failed)
    Write-Host ("Elapsed : {0:N1} sec" -f $stopwatch.Elapsed.TotalSeconds)
    Write-Host '============================='
}
