本工具使用前提：

* 当前电脑已安装 Office 套件



本工具使用步骤：

1.将需要批量转PDF的Word文档置于本工具统一目录。

2.选中本工具“convert-word-to-pdf.ps1”，点击鼠标右键，选择“Power Sheell 运行”。

&#x20;  运行后本工具会自动将同一目录下的所有Word批量转PDF，且自动添加书签。

3.可阅读“README-word2pdf.md”了解该工具更多描述。

