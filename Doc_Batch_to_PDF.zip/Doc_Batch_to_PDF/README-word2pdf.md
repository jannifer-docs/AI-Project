# Word Batch to PDF Tool (PowerShell)

This tool converts Word files in a local folder to PDF in batch mode.

## Features

- Supports `.docx` and `.doc`
- Uses script directory as default input path when `-InputPath` is omitted
- Scans only current folder by default (non-recursive)
- **Exports PDF bookmarks by default** (from Word heading styles)
- Configurable PDF bookmark mode: `Headings`, `WordBookmarks`, `None`
- Default conflict strategy: skip existing PDF files
- Keeps converting even if single files fail
- Prints summary statistics at the end

## Prerequisites

- Windows
- Microsoft Word desktop installed
- PowerShell 5.1+ (or PowerShell 7 with Word COM compatibility)

## Files

- `convert-word-to-pdf.ps1`: main conversion script

## Quick Start

Open PowerShell in this folder, then run:

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
.\convert-word-to-pdf.ps1
```

## Parameters

- `-InputPath <string>`: optional. File or directory path. If omitted, script directory is used.
- `-Recurse <bool>`: optional. Default is `$false`.
- `-ConflictAction <Skip|Overwrite|Rename>`: optional. Default is `Skip`.
- `-Extensions <string[]>`: optional. Default is `@('.docx', '.doc')`.
- `-BookmarkMode <None|Headings|WordBookmarks>`: optional. Default is `Headings`.
- `-LogFile <string>`: optional. Path to log file.
- `-RetryCount <0..3>`: optional. Retries per file. Default is `1`.

## Examples

Convert all `.doc/.docx` in script directory (default behavior):

```powershell
.\convert-word-to-pdf.ps1
```

Convert all `.doc/.docx` in script directory and all subdirectories:

```powershell
.\convert-word-to-pdf.ps1 -Recurse $true
```

Convert one specific directory without recursion:

```powershell
.\convert-word-to-pdf.ps1 -InputPath 'D:\Docs' -Recurse $false
```

Overwrite existing PDFs:

```powershell
.\convert-word-to-pdf.ps1 -InputPath 'D:\Docs' -ConflictAction Overwrite
```

Disable PDF bookmarks:

```powershell
.\convert-word-to-pdf.ps1 -BookmarkMode None
```

Use Word bookmarks instead of heading-based bookmarks:

```powershell
.\convert-word-to-pdf.ps1 -BookmarkMode WordBookmarks
```

Write logs to a file:

```powershell
.\convert-word-to-pdf.ps1 -InputPath 'D:\Docs' -LogFile '.\convert.log'
```

## Troubleshooting

- **PDF has no bookmarks?** Verify that your Word document uses actual Heading 1, Heading 2, etc. styles for the outline. Bold or larger text alone does not create bookmarks; only proper heading styles are converted to PDF bookmarks.
- If files fail to convert, check whether they are open in Word.
- If Word prompts or protected mode blocks opening, open and trust the document manually once.
- If permission errors occur, ensure write permission in target folders.
- By default, existing PDFs are skipped. Use `-ConflictAction Overwrite` to replace them, or `-ConflictAction Rename` to save with a numbered suffix.
